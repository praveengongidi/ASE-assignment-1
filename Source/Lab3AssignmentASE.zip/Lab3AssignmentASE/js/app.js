var AddressBook = angular.module('AddressBook', []);

AddressBook.controller('PersonController', function ($scope) {
  
});
