$(document).ready(function(){
	//var success = 0;

	$('#registrationform').on("submit",function(e){
        alert("hi");
		e.preventDefault();
		if(localStorage){
			localStorage.setItem("firstname",$('#firstname').val() );
            localStorage.setItem("dob",$('#dob').val() );
            localStorage.setItem($('uname').val(),$('#pwd').val()  );
            localStorage.setItem("mobileno",$('#mobileno').val() );
            localStorage.setItem("email",$('#email').val() );
            
		}
	});
	
	$('#login-form').on("submit",function(e){
		//if(success==0){	
			e.preventDefault();
		}
		if(localStorage){
			if(! localStorage.getItem( $('#uname').val() ) ) {
				alert("UserName doesn't exist");
			} else if( localStorage.getItem( $('#uname').val() ) != $('#pwd').val() ) {	
				alert("Invalid Password");
			} else {
                //alert("hi");
				location.href = "chitchathome.html";
				//success=1;
				//$(this).submit();
			}
		}
	})
	
})