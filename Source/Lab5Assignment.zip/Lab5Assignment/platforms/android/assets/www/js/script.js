function function1(){ 
            
            alert("hi");
            var x=localStorage.getItem("uname1");
            var y=localStorage.getItem(x);
            if(x==document.getElementById("username").value)
            {
                if(document.getElementById("pwd").value==y)
                {
                 return true;
                }
                else{ alert("password is wrong");
                     return false;
                    }
            }
            else{
                    alert("username doesnot exist");
                return false;
                }
}