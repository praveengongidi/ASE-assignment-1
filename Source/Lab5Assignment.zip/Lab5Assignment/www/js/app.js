// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})


.controller('googlemapoutput', function ($scope) {

    alert('hi');
    var map;
    var mapOptions;
    var directionsDisplay = new google.maps.DirectionsRenderer({
        draggable: true
    });
    var directionsService = new google.maps.DirectionsService();

    $scope.initialize = function () {
          var pos = new google.maps.LatLng(0, 0); 
          var mapOptions = {
                zoom: 3,
                center: pos
            };

            map = new google.maps.Map(document.getElementById('map-canvas'),
            mapOptions);
     };
    $scope.calcRoute = function () {
       var end = document.getElementById('endlocation').value;
            var start = document.getElementById('startlocation').value;

            var request = {
                origin: start,
                destination: end,
                travelMode: google.maps.TravelMode.DRIVING
            };

            directionsService.route(request, function (response, status) {
                if (status == google.maps.DirectionsStatus.OK) {
                    directionsDisplay.setMap(map);
                    directionsDisplay.setDirections(response);
                    console.log(status);
                }
           
        });
    };

    google.maps.event.addDomListener(window, 'load', $scope.initialize);

});

 

function function1(){ 
            
            alert("hi");
            var x=localStorage.getItem("uname1");
            var y=localStorage.getItem(x);
            if(x==document.getElementById("username").value)
            {
                if(document.getElementById("pwd").value==y)
                {
                 return true;
                }
                else{ alert("password is wrong");
                     return false;
                    }
            }
            else{
                    alert("username doesnot exist");
                return false;
                }
}

function function2(){ 
            if(localStorage){
			localStorage.setItem("firstname",document.getElementById('firstname').value);
            localStorage.setItem("dob",document.getElementById('dob').value);
            localStorage.setItem("uname1",document.getElementById('uname').value);
            localStorage.setItem("pwd1",document.getElementById('pwd').value);
            localStorage.setItem(document.getElementById("uname").value,document.getElementById('pwd').value  );
            localStorage.setItem("mobileno",document.getElementById('mobileno').value);
            localStorage.setItem("email",document.getElementById('email').value );
            
		}
}




         
